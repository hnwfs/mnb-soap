from .mnb import *

__version__ = '0.1'
__author__  = 'Világi Norbert'
